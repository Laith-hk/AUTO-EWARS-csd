
library(dplyr)

pred_dat_Dic<-tribble(~var,~Var_definition,
                      "district",'District',
                      "year",'Year',
                      "week",'week',
                      "meantemperature",' ',
                      "rhdailymean",' ',
                      "rain_scaled_std",' ',
                      "Cases",'Weekly_observed_cases',
                      "population",'Ppoulation',
                      "observed_rate",'Incidence rate per 100000 :(Cases/population)*100000',
                      "endemic_chanel",'Outbreak threshold based historical mean +(zvalue*Standard deviation)',
                      "predicted_cases",'Mean  predicted cases',
                      "predicted_cases_lci",'Lower confidence interval of predicted cases',
                      "predicted_cases_uci",'Upper confidence interval of predicted cases',
                      "predicted_rate",'Incidence rate per 100000 :(predicted_cases/population)*100000',
                      "predicted_rate_lci",'Lower confidence interval of predicted rate',
                      "predicted_rate_uci",'Upper confidence interval of predicted rate',
                      "alarm_threshold",'Computed threshold based on ROC analysis',
                      "outbreak_probability",'probability of predicted rate exceeding endemic_chanel',
                      "alarm_signal",'weeks when outbreak_probability>alarm_threshold',
                      "outbreak_period",'weeks when observed_rate>endemic_chanel',
                      "pred_Distance",'estimated prediction distance ',
                      "response_cat",'response option',)


write.csv(pred_dat_Dic,"prospective_data_Dictionary.csv",row.names =F)