##Output from API runs

library(rjson)
library(dplyr)
library(stringr)
library(flextable)
library(foreach)
library(ggplot2)
library(leaflet)
library(dlnm)
library(RColorBrewer)
library(lubridate)
library(xts)
library(dygraphs)
#library(quarto)
library(raster)


out_Path<-out_path


shiny_obj_Main_pth<-file.path(out_Path,"For_Shiny")
all_files_Path<-file.path(out_Path,"For_Shiny","All_district")

get_Ojs<-function(){
  gc()
  readRDS(file.path(all_files_Path,"Shiny_Objs_all.rds"))
  
  
}

all_Objs<-get_Ojs()

data_augmented<-all_Objs[["data_augmented"]]

#all_districts<-sort(unique(data_augmented$district))
all_districts<-sort(unique(data_augmented$district))[1]


for (DD in 1:length(all_districts)){
  
  District_Now<-all_districts[DD]
  
  
  gc()
  
  # boundary_file<-all_Objs$
  # shp_data<-boundary_file@data
  
  alarm_vars<-all_Objs[["alarm_vars"]]
  covar_to_Plot<-all_Objs[["covar_to_Plot"]]
  vars_get_summary<-all_Objs[["vars_get_summary"]]
  all_Plot_Poly<-all_Objs[["all_Plot_Poly"]]
  all_xts_Plots<-all_Objs[["all_xts_Plots"]]
  leaflet_plots<-all_Objs[["leaflet_plots"]]
  nlag<-all_Objs[["nlag"]]
  data_augmented<-all_Objs[["data_augmented"]]
  all_endemic<-all_Objs[["all_endemic"]]
  sel_var_endemic<-all_Objs[["sel_var_endemic"]]
  names_cov_Plot<-all_Objs[["names_cov_Plot"]]
  
  base_vars<-c("district","year","week")
  
  number_of_cases<-all_Objs[["number_of_cases"]]
  pop.var.dat<-all_Objs[["pop.var.dat"]]
  
  
  dist<-data_augmented$district
  years.dat<-sort(unique(data_augmented$year))
  
  # for(i in 1:length(covar_to_Plot)){
  #   
  #   text_rend1<-paste0('output$time_series_plot_',i,'<-renderDygraph({
  #                      all_xts_Plots[[',i,']]})'
  #   )
  #   eval(parse(text=text_rend1))
  # }
  
  ## show the xts Plots
  
  all_xts_Plots
  
  all_xts_Plots[[1]]
  
  alarm.indicators<-alarm_indicators
  
  # dat_A<-data_augmented %>% 
  #   dplyr::arrange(district,year,week) %>% 
  #   dplyr::filter(district %in% boundary_file$district &!week==53)
  
  dat_A<-data_augmented %>% 
    dplyr::arrange(district,year,week) %>% 
    dplyr::filter(!week==53)
  
  ## balance the observations to compute expected cases correctly
  
  beg.year<-min(dat_A$year)
  end.year<-max(dat_A$year)
  
  
  new_model_Year_validation<-end.year
  
  cat(paste('\nValidation year Beg ..\n',new_model_Year_validation),'\n\n')
  
  district_new<-District_Now
  
  dist_padded<-str_pad(district_new,side="left",width=3,pad=0)
  shiny_obj_pth<-file.path(shiny_obj_Main_pth,paste0("District_",dist_padded))
  
  
  get_Ojs1<-function(){
    gc()
    readRDS(file.path(shiny_obj_pth,"Shiny_Objs.rds"))
    
    
  }
  
  shiny_obj1<-get_Ojs1()
  reporT_pAth0<-shiny_obj1[["report_pth"]]
  reporT_pAth<-stringr::str_replace(reporT_pAth0,'.',getwd())
  ##changes
  
  # tab_Dat<-shiny_obj1[["tab_Dat"]]
  # tab_Dat_lag<-shiny_obj1[["tab_Dat_lag"]]
  
  dat_kl_Long<-shiny_obj1[["dat_kl_Long"]]
  Lag_dic_comp1_Long<-shiny_obj1[["Lag_dic_comp1_Long"]]
  
  tab_Dat<-tabulator(x=dat_kl_Long,
                     rows=c("Variable","Year"),
                     columns=c("variable"),
                     ystats=as_paragraph(value)
  )
  
  
  tab_Dat_lag<-tabulator(x=Lag_dic_comp1_Long,
                         rows=c("Variable","var"),
                         columns=c("variable"),
                         ystats=as_paragraph(value)
  )
  
  dat_kl<-shiny_obj1[["dat_kl"]]
  all_kl_cmd<-shiny_obj1[["all_kl_cmd"]]
  all_kl_cmd1<-str_replace(all_kl_cmd,'unique[(]dat_sum_long[$]district[)]','district_new')
  
  plot_List0<-shiny_obj1[["summary_plots"]]
  
  plot_List<-shiny_obj1[["plot_List"]]
  rows_01<-shiny_obj1[["rows_01"]]
  
  cat(paste0('\ncovar_to_Plot:\n'),paste(covar_to_Plot,sep=' '),'\n\n')
  
  
  flex_tab1_tribble<-tribble(~var,
                             "function(){",
                             "tab_Dat |> ",
                             "as_flextable() |>",
                             "flextable::set_caption(as_paragraph(paste('District ',input$district_new)),",
                             "fp_p=officer::fp_par(text.align = 'left')) |> ",
                             "flextable::fit_to_width(max_width =12,unit='in') |> ",
                             "flextable::fontsize(part='header',size=14) |> ",
                             "flextable::fontsize(part='body',size=10) |> ",
                             "flextable::font(part='all',fontname ='Courier') |> ",
                             "flextable::padding(part='body',padding = 4) |> ",
                             "flextable::bold(i=1,part ='header') |> ",
                             "flextable::border_inner_h(border =border_prop) |> ",
                             "flextable::color(i=1,color='#CCBB44',part='header') |> ",
                             "flextable::bg(j=16,bg='#94a323') |> ",
                             "flextable::align(part='all',align ='left') |> ",
                             "htmltools_value()",
                             "}"
  )
  
  
  border_prop<-officer::fp_border(width=0.5)
  
  
  tab_Dat |> 
    as_flextable() |> 
    #flextable::autofit(add_w=0,add_h=10,unit='mm',part='body') |> 
    flextable::set_caption(as_paragraph(paste('District ',district_new)),
                           fp_p=officer::fp_par(text.align = "left")) |> 
    flextable::fit_to_width(max_width =9,unit='in') |> 
    flextable::fontsize(part='header',size=12) |> 
    flextable::fontsize(part='body',size=9) |> 
    flextable::font(part='all',fontname ="Arial") |> 
    flextable::padding(part="body",padding = 2) |> 
    flextable::bold(i=1,part ="header") |> 
    flextable::border_inner_h(border =border_prop) |> 
    flextable::color(i=1,color="#CCBB44",part="header") |> 
    flextable::bg(j=16,bg="#94a323") |> 
    flextable::align(part='body',align ="center") |> 
    flextable::border_remove() |> 
    flextable::hline() |> 
    flextable::hline_top() |> 
    flextable::htmltools_value()
  
  border_prop<-officer::fp_border(width=0.5)
  
  tab_Dat_lag |> 
    as_flextable() |> 
    #flextable::autofit(add_w=0,add_h=10,unit='mm',part='body') |> 
    flextable::set_caption(as_paragraph(paste('District ',district_new)),
                           fp_p=officer::fp_par(text.align = "left")) |> 
    flextable::fit_to_width(max_width =12,unit='in') |> 
    flextable::fontsize(part='header',size=12) |> 
    flextable::fontsize(part='body',size=9) |> 
    flextable::font(part='all',fontname ="Arial") |> 
    flextable::padding(part="body",padding = 2) |> 
    flextable::bold(i=1,part ="header") |> 
    flextable::border_inner_h(border =border_prop) |> 
    flextable::color(i=1,color="#CCBB44",part="header") |> 
    flextable::bg(i=rows_01,j=2:16,bg="#4477AA",part="body") |> 
    flextable::border_remove() |> 
    flextable::align(part='body',align ="center") |> 
    flextable::hline() |> 
    flextable::hline_top() |> 
    flextable::htmltools_value()
  
  cat(paste("Summary variables ::\n"),paste(vars_get_summary,collapse =','),'\n\n')
  
  ## descriptive Plots
  plot_List0
  
  seasonal_plot<-shiny_obj1[["seasonal_plot"]]
  
  
  
  new_model_Year_plot<-end.year
  var_p<-names_cov_Plot
  
  new_model_Week_plot_spat<-26
  
  yr_week<-paste0(new_model_Year_plot,'_',str_pad(new_model_Week_plot_spat,side ="left",pad =0,width =2))
  yr_week1<-paste0(new_model_Year_plot,':',str_pad(new_model_Week_plot_spat,side ="left",pad =0,width =2))
  
  yr_week_input<-paste0(new_model_Year_plot,":",str_pad(new_model_Week_plot_spat,side ="left",pad =0,width =2))
  yr_week_input1<-paste0(new_model_Year_plot,"_",str_pad(new_model_Week_plot_spat,side ="left",pad =0,width =2))
  
  # par_text1<-get_UI_update_d(obj.plots=covar_to_Plot,
  #                            panel_Update="Spat_Covariate_Plots_new_Model" ,
  #                            shinyOutputType="leafletOutput",
  #                            cols=2,
  #                            out_ref="spat_cov")
  
  
  cat(paste("\nfrom input ::",yr_week_input,'\n\n'))
  
  
  plot_Func<-function(p){
    #browser()
    plot_Now<-all_Plot_Poly[[var_p[p]]]
    week.idx<-which(names(plot_Now)==yr_week)
    week_slice<-plot_Now[,c("district",yr_week)]
    
    lng1<-as.numeric(week_slice@bbox[,1][1])
    lat1<-as.numeric(week_slice@bbox[,1][2])
    lng2<-as.numeric(week_slice@bbox[,2][1])
    lat2<-as.numeric(week_slice@bbox[,2][2])
    
    labels <- sprintf(
      "<strong>%s</strong><br/>%g",
      week_slice$district, eval(parse(text=paste0("week_slice$`",yr_week,"`")))
    ) %>% lapply(htmltools::HTML)
    
    
    legend_title<-sprintf(
      "<strong>%s</strong><br/>%s",
      var_p[p],yr_week1 
    ) %>% lapply(htmltools::HTML)
    
    id.summ<-str_detect(names(week_slice),"[:number:]+_[:number:]+")
    
    dom_comp<-unique(as.numeric(unlist((week_slice[,id.summ]@data))))
    
    len.dom<-length(dom_comp)
    if(len.dom==1){
      if(is.na(dom_comp)){
        dom_range<-c(eval(parse(text=paste0("week_slice$`",yr_week,"`"))),1)
        
      }else{
        dom_range<-c(eval(parse(text=paste0("week_slice$`",yr_week,"`"))))
        
      }
    }else{
      dom_range<-eval(parse(text=paste0("week_slice$`",yr_week,"`")))
    }
    pal <- colorNumeric("YlOrRd", 
                        domain =dom_range,
                        reverse=F) 
    plo1<-leaflet(week_slice[,yr_week]) %>% 
      leaflet::addTiles() %>% 
      leaflet::addProviderTiles(providers$OpenStreetMap) %>% 
      leaflet::fitBounds(lng1,lat1,lng2,lat2) %>% 
      #addPolylines() %>% 
      leaflet::addPolygons(fillColor = eval(parse(text=paste0("~pal(`",yr_week,"`)"))),
                           color = "black",weight =0.8,
                           dashArray = " ",
                           fillOpacity = 0.9,
                           highlight = highlightOptions(
                             weight = 5,
                             color = "green",
                             dashArray = "2",
                             fillOpacity = 0.7,
                             bringToFront = TRUE),
                           label = labels,
                           labelOptions = labelOptions(
                             style = list("font-weight" = "normal", padding = "3px 8px"),
                             textsize = "15px",
                             direction = "auto")) %>% 
      leaflet::addLegend(pal = pal, values = eval(parse(text=paste0("~`",yr_week,"`"))), 
                         opacity = 0.7, title = legend_title,
                         position = "bottomright") 
    list(plo1)
    
  }
  
  plot_List<-foreach(a=1:length(var_p),.combine =c)%do% plot_Func(a)
  
  alarm_indicators
  for_obs<-foreach(a=1:length(alarm_indicators),.combine =c) %do% paste0('input$',alarm_indicators[a],'_',1:3)
  
  data.basis<-shiny_obj1[["Dat_mod_for_dlnn"]]
  nlag<-nlag
  
  alarm_indicators_New_model<-alarm_vars
  alarm_vars_lag<-alarm_indicators_New_model
  all_basis_vars<-shiny_obj1[["all_basis_vars"]]
  basis_var_n<-paste0('all_basis_vars$',names(all_basis_vars))
  alarm.indicators<-alarm_indicators_New_model
  dat_slider<-data.basis
  
  basis_vars_lag<-names(all_basis_vars)
  alarm_vars_lag<-alarm_indicators_New_model
  
  #model_dlnm<-shiny_obj1[["dlnm_Model"]]
  
  dlnm_coef <- shiny_obj1[["dlnm_coef"]]
  dlnm_vcov <- shiny_obj1[["dlnm_vcov"]]
  dlnm_names_fixed<-shiny_obj1[["dlnm_names_fixed"]]
  
  #p<-1
  
  get_lag_plots<-function(p){
    
    plot_dlnm_env<-new.env()
    
    
    
    if(str_detect(alarm_vars_lag[p],'rain|prec|precipitation')){
      ylab.text<-paste(alarm_vars_lag[p],'(mm)')
    }else if(str_detect(alarm_vars_lag[p],'temp')){
      #ylab.text<-paste0('"',alarm_vars_lag[p],'"','~(','~degree~C)')
      #ylab.text<-paste0('"',alarm_vars_lag[p],'"','~(','~degree~C)')
      ylab.text<-alarm_vars_lag[p]
    }else if(str_detect(alarm_vars_lag[p],'RH|rh')){
      ylab.text<-paste(alarm_vars_lag[p],'(%)')
    }else{
      ylab.text<-alarm_vars_lag[p]
    }
    
    assign("ylab_text",ylab.text,envir =plot_dlnm_env)
    
    
    temp_var<-str_detect(alarm_vars_lag[p],'temp')
    cat(paste(basis_var_n,'\n\n'))
    
    coef <- dlnm_coef
    vcov <- dlnm_vcov
    indt <- grep(basis_vars_lag[p], dlnm_names_fixed)
    
    computed_basis<-eval(parse(text=(basis_var_n[p])))
    #assign("computed_basis",eval(parse(text=(basis_var_n[p]))))
    
    centering.val=round(mean(data.basis[,alarm_vars_lag[p]],na.rm=T), 0)
    
    min<-round(min(data.basis[,alarm_vars_lag[p]],na.rm=T),0)
    min.1<-min(data.basis[,alarm_vars_lag[p]],na.rm=T)
    max<-round(max(data.basis[,alarm_vars_lag[p]],na.rm=T),0)
    max.1<-max(data.basis[,alarm_vars_lag[p]],na.rm=T)
    
    val.slid<-pretty(min:max,50)
    
    
    predt.h <- crosspred(computed_basis, coef = coef[indt], vcov=vcov[indt,indt],
                         at=val.slid,
                         model.link = "log", bylag = 0.25, cen =centering.val) 
    
    #dat_plot<-data.frame(x=predt.h$predvar,y=seq(0, nlag, 0.25),z=t(predt.h$matRRfit))
    
    plot_d<-reshape2::melt(predt.h$matRRfit) %>% 
      dplyr::mutate(x=as.numeric(str_remove(Var2,"lag")),
                    y=as.numeric(Var1),
                    RR=value) %>% 
      dplyr::select(x,y,RR)
    
    plot_d_lci<-reshape2::melt(predt.h$matRRlow) %>% 
      dplyr::mutate(x=as.numeric(str_remove(Var2,"lag")),
                    y=as.numeric(Var1),
                    RR_low=value)%>% 
      dplyr::select(x,y,RR_low)
    
    plot_d_hci<-reshape2::melt(predt.h$matRRhigh) %>% 
      dplyr::mutate(x=as.numeric(str_remove(Var2,"lag")),
                    y=as.numeric(Var1),
                    RR_high=value)%>% 
      dplyr::select(x,y,RR_high)
    
    pal <- rev(brewer.pal(11, "PRGn"))
    levels <- pretty(predt.h$matRRfit, 20)
    col1 <- colorRampPalette(pal[1:6])
    col2 <- colorRampPalette(pal[6:11])
    cols <- c(col1(sum(levels < 1)), col2(sum(levels > 1)))
    
    
    lag_slices<-plot_d_lci %>% 
      dplyr::left_join(plot_d,by=c("x","y")) %>% 
      dplyr::left_join(plot_d_hci,by=c("x","y"))
    
    cont_plot<-ggplot(aes(x=x,y=y),data=plot_d)+
      geom_contour_filled(aes(z=RR),
                          breaks=levels)+
      scale_fill_manual(values =cols)+
      theme_bw()+
      guides(fill=guide_coloursteps(reverse =F,
                                    title="RR",
                                    ticks=F,
                                    barheight=grid::unit(10,'cm')))+
      theme(panel.grid =element_blank(),
            axis.title =element_text(size=16),
            axis.text =element_text(size=14))+
      scale_x_continuous(breaks=0:nlag,
                         expand =c(0,0))+
      scale_y_continuous(breaks=pretty(plot_d$y,15),
                         expand =c(0,0))+
      
      xlab("Lag Weeks")+
      if(temp_var){
        #ylab(eval(parse(text=ylab.text)))
        ylab(bquote(.(ylab_text)~degree~C,where=plot_dlnm_env))
      }else{
        ylab(ylab.text)
      }
    
    pout<-list(cont_plot,lag_slices)
    
    names(pout)<-c(paste0("ContPlot_",alarm_vars_lag[p]),paste0("datLagSlices_",alarm_vars_lag[p]))
    pout
  }
  #browser()
  if(Run_Dlnm){
    all_cont_dat_plots<-foreach(a=1:length(alarm_vars),.combine =c)%do% get_lag_plots(a)
    all_cont_plots<-all_cont_dat_plots[grep('ContPlot',names(all_cont_dat_plots))]
    all_datLagSlices<-all_cont_dat_plots[grep('datLagSlices',names(all_cont_dat_plots))]
    
    
    basis_vars_lag<-names(all_basis_vars)
    alarm_vars_lag<-alarm_indicators_New_model
    
    dat_slider<-dat_A
    
    p<-1
    var.Obj<-"alarm.indicators"
    
    get_fluid_slice_Output<-function(p,var.Obj){
      
      var<-get(var.Obj)[p]
      #dat_slider<-var_names_New_model()$dat
      min<-round(min(dat_slider[,var],na.rm=T),0)
      min.1<-min(dat_slider[,var],na.rm=T)
      max<-round(max(dat_slider[,var],na.rm=T),0)
      max.1<-max(dat_slider[,var],na.rm=T)
      
      val.slid<-pretty(min:max,50)
      id.rm<-which(val.slid<min.1|val.slid>max.1)
      if(length(id.rm)>0){
        val.sliders<-val.slid[-which(val.slid<min.1|val.slid>max.1)]
        
      }else{
        val.sliders<-val.slid
      }
      
      
      min.slid<-min(val.sliders,na.rm=T)
      max.slid<-max(val.sliders,na.rm=T)
      
      if(str_detect(paste0(val.sliders[2]),'[.]')){
        dec_points<-str_length(str_extract(val.sliders[2],'[.][:number:]+'))-1
        
        step.val<-round(unique(diff(val.sliders))[1],dec_points)
      }else{
        step.val<-unique(diff(val.sliders))[1]
      }  
      values_length<-1:length(val.sliders)
      
      sel_idx<-c(as.integer(quantile(values_length,0.25)),
                 as.integer(quantile(values_length,0.35)),
                 as.integer(quantile(values_length,0.95)))
      
      vals_beg<-val.sliders[sel_idx]
      
      pp<-1
      
      get_slider_input_lag<-function(var,pp){
        
        
        aa<-tribble(~var,~value,
                    paste0(var,'_',pp),vals_beg[pp],
                    
        )
        aa
      }
      
      
      all_slider<-foreach(a=1:3,.combine =rbind)%do% get_slider_input_lag(var,a)
      
    }
    
    
    
    Slice_Input0<-foreach(a=1:length(alarm_indicators),.combine = rbind)%do% get_fluid_slice_Output(a,'alarm.indicators')
    
    Slice_Input1<-Slice_Input0$value
    
    
    
    names(Slice_Input1)<-Slice_Input0$var
    
    Slice_Input<-data.frame(t(Slice_Input1))
    
    get_lag_slice_plots<-function(p){
      
      
      
      centering.val<-round(mean(data.basis[,alarm_vars_lag[p]],na.rm=T), 0)
      
      
      if(str_detect(alarm_vars_lag[p],'rain|prec|precipitation')){
        cen.text<-paste0('Reference=',centering.val,'mm')
      }else if(str_detect(alarm_vars_lag[p],'temp')){
        cen.text<-paste0("'Reference='~",centering.val,'~degree~C')
      }else if(str_detect(alarm_vars_lag[p],'RH|rh')){
        cen.text<-paste0('Reference=',centering.val,'%')
      }else{
        cen.text<-paste0('Reference=',centering.val)
      }
      
      temp_var<-str_detect(alarm_vars_lag[p],'temp')
      
      ## get values to choose
      
      ad.v<-paste0('Slice_Input$',alarm_vars_lag[p],'_',1:3)
      
      cat(paste("selected lag values ..\n\n"),eval(parse(text=paste0('c(',paste0(ad.v,collapse =','),')'))),'\n')
      
      sel_sli_p<-eval(parse(text=paste0('c(',paste0(ad.v,collapse =','),')')))
      
      paste(Slice_Input$meantemperature_1)
      #dat_plot<-data.frame(x=predt.h$predvar,y=seq(0, nlag, 0.25),z=t(predt.h$matRRfit))
      
      
      lag_slices<-all_datLagSlices[[p]]
      pal <- rev(brewer.pal(11, "PRGn"))
      levels <- pretty(lag_slices$RR, 20)
      col1 <- colorRampPalette(pal[1:6])
      col2 <- colorRampPalette(pal[6:11])
      cols <- c(col1(sum(levels < 1)), col2(sum(levels > 1)))
      
      
      #unique(plot_d$y)
      #lag_slices_see<<-lag_slices
      dat_some<-lag_slices %>% 
        dplyr::filter(y%in%  sort(sel_sli_p)) %>% 
        #dplyr::filter(y%in%  sample(lag_slices$y,3)) %>% 
        dplyr::mutate(y_fac=as.factor(y),
                      temp_var=temp_var,
                      ref=cen.text
        )
      
      
      names(dat_some)
      
      min.y_s<-min(c(dat_some$RR_low,dat_some$RR,dat_some$RR_high))
      max.y_s<-max(c(dat_some$RR_low,dat_some$RR,dat_some$RR_high))
      
      
      
      #library(viridis)
      
      slice.p<- ggplot(aes(x=x,y=RR),data=dat_some)+
        geom_line(aes(col=y_fac))+
        geom_ribbon(aes(ymin=RR_low,ymax=RR_high,fill=y_fac),alpha=0.1,
                    show.legend =F)+
        geom_hline(aes(yintercept=1),lty=2,linewidth=0.8)+
        facet_wrap(~ref,labeller =if(temp_var){label_parsed}else{label_value})+
        theme_bw()+
        scale_color_manual(values=viridis::plasma(20)[c(2,14,8)] )+
        scale_fill_manual(values=viridis::plasma(20)[c(2,14,8)])+
        scale_x_continuous(breaks=0:nlag,
                           expand =c(0,0))+
        scale_y_continuous(limits =c(min.y_s,max.y_s*1.5))+
        xlab("Lag Weeks")+
        ylab("RR")+
        guides(col=guide_legend(title=alarm_vars_lag[p]))+
        theme(panel.grid.minor =element_blank(),
              strip.text =element_text(size=18,face="bold",colour ="black"),
              legend.text =element_text(size=18),
              legend.title =element_text(size=18),
              axis.text =element_text(size=14),
              axis.title =element_text(size=16),
              legend.position ="bottom")
      
      pout<-list(slice.p)
      names(pout)<-alarm_vars_lag[p]
      pout
    }
    
    all_lag_slice_plots<-foreach(a=1:length(basis_vars_lag),.combine =c)%do% get_lag_slice_plots(a)
    
  }
  
  district_validation<-district_new
  
  #model_final_rw<- shiny_obj1[["model_final_rw"]]
  model_final_rw_fitted_Values<-shiny_obj1[["model_final_rw_fitted_Values"]]
  
  all_cv<-shiny_obj1[["all_cv"]]
  y.PREDS<-shiny_obj1[["y.PREDS"]]
  selected_zvalue<-shiny_obj1[["selected_zvalue"]]
  
  
  Z_Value<-selected_zvalue
  
  cat(paste('Z_value::',Z_Value),'\n\n')
  
  for_endemic<-all_endemic |> 
    dplyr::filter(district==district_validation) |> 
    dplyr::mutate(threshold_cases=mean_cases+Z_Value*(sd_cases),
                  threshold_rate=mean_rate+Z_Value*(sd_rate))
  
  dat_augmented_Sub<-data_augmented |> 
    dplyr::filter(district==district_validation) |> 
    dplyr::arrange(district,year,week)
  
  dat.4.endemic<-dat_augmented_Sub[,sel_var_endemic]
  names(dat.4.endemic)<-c(base_vars,"cases","pop")
  
  idx_runin<-which(!dat_augmented_Sub$year>=new_model_Year_validation)
  
  
  runin_dat<-dat.4.endemic |> 
    dplyr::filter(!year>=new_model_Year_validation) |> 
    dplyr::mutate(observed_cases=cases,
                  observed_rate=(cases/pop)*1e5,
                  fitted=model_final_rw_fitted_Values$mean[idx_runin],
                  fitted=(fitted/pop)*1e5,
                  fittedp25=model_final_rw_fitted_Values$`0.025quant`[idx_runin],
                  fittedp25=(fittedp25/pop)*1e5,
                  fittedp975=model_final_rw_fitted_Values$`0.975quant`[idx_runin],
                  fittedp975=(fittedp975/pop)*1e5,
    ) %>% 
    dplyr::left_join(for_endemic,by=c("district","year","week")) |> 
    dplyr::mutate(
      #outbreak=observed_cases>threshold_cases,
      outbreak=observed_rate>threshold_rate,
      observed_alarm=case_when(outbreak==1~observed_rate,
                               TRUE~as.numeric(NA))) |> 
    dplyr::select(district,year,week,observed_rate,fitted,fittedp25,fittedp975,outbreak,threshold_rate,observed_alarm)
  
  cat(paste("district is<<>>",district_validation),'\n')
  
  end.runin.year<-new_model_Year_validation-1
  #date_week_runin<-seq.Date(as.Date(paste0(beg.year,'-01-01')),as.Date(paste0(end.runin.year,'-12-31')),by='week')[-1]
  #date_week_runin<-seq.Date(as.Date(paste0(beg.year,'-01-01')),as.Date(paste0(end.runin.year,'-12-31')),by='week')
  date_week_runin<-foreach(yr=sort(unique(runin_dat$year)),.combine =c)%do% seq.Date(as.Date(paste0(yr,'-01-01')),as.Date(paste0(yr,'-12-31')),by='week')
  
  
  
  data_Weeks_Runin_prev<-data.frame(date=date_week_runin,
                                    year_week=format.Date(date_week_runin,"%Y_%W"),
                                    year=year(date_week_runin),
                                    stringsAsFactors =F,
                                    week=week(date_week_runin)) %>% 
    mutate(Week=str_split_fixed(year_week,pattern ='_',n=2)[,2]) %>% 
    dplyr::filter(as.numeric(Week)%in% 1:52)
  
  data_Weeks_Runin<-data.frame(date=date_week_runin,
                               year_week=format.Date(date_week_runin,"%Y_%W"),
                               year=year(date_week_runin),
                               stringsAsFactors =F,
                               week=week(date_week_runin)) %>% 
    mutate(Week=str_split_fixed(year_week,pattern ='_',n=2)[,2]) |> 
    dplyr::select(-year_week)
  
  
  weeks.in.data_runin<-data_augmented %>% 
    dplyr::mutate(year_week=paste0(year,'-',str_pad(week,side ="left",pad =0,width =2))) 
  
  year_week_S_runin<-data_Weeks_Runin %>% dplyr::group_by(year,Week) %>% 
    dplyr::summarise(.groups="drop",date_Beg=min(date)) %>% 
    dplyr::mutate(year_week=format.Date(date_Beg,"%Y-%W"))%>% 
    dplyr::filter(year_week %in% weeks.in.data_runin$year_week)
  
  
  data_plot_Runin<-runin_dat |> 
    dplyr::left_join(data_Weeks_Runin,by=c("year","week"))
  
  data_plot_RuninB<-data_plot_Runin |> 
    dplyr::select(observed_rate,fitted,fittedp25,
                  fittedp975,outbreak,
                  threshold_rate,observed_alarm)  |>  
    dplyr::rename(observed=observed_rate,
                  threshold=threshold_rate)
  
  # data_use_Runin_xts<-xts(data_plot_RuninB,order.by =year_week_S_runin$date_Beg,
  #                         frequency=7)
  
  data_use_Runin_xts<-xts(data_plot_RuninB,order.by =data_plot_Runin$date,
                          frequency=7)
  
  data_plot_RuninB1<-data_plot_Runin |> 
    #dplyr::mutate(date=year_week_S_runin$date_Beg) |> 
    dplyr::select(date,observed_rate,fitted,fittedp25,
                  fittedp975,outbreak,
                  threshold_rate,observed_alarm)|> 
    dplyr::rename(observed=observed_rate,
                  threshold=threshold_rate)
  
  
  
  plot.runin<-ggplot(aes(x=date),data=data_plot_RuninB1)+
    geom_line(aes(x=date,y=observed,col="Observed"),linewidth=0.82)+
    geom_line(aes(x=date,y=fitted,col='Predicted'),linewidth=1.2,lty=1)+
    geom_line(aes(x=date,y=threshold),linewidth=1.1,lty=1,col='blue',show.legend =F)+
    geom_area(aes(x=date,y=threshold,fill='Endemic'),alpha=0.7)+
    geom_point(aes(x=date,y=observed_alarm,col="Outbreak"),size=3)+
    geom_ribbon(aes(ymin=fittedp25,ymax=fittedp975,
                    fill="95 % CI"),alpha=0.3)+
    scale_color_manual(values=c("Observed"='#00336FFF',
                                "Predicted"='#A72197FF',
                                #"Endemic"='lightblue2',
                                "Outbreak"='orange2'))+
    scale_fill_manual(values=c("Endemic"='lightblue2',
                               "95 % CI"=grey(0.3)))+
    
    scale_x_date(date_breaks ="52 weeks")+
    theme_bw()+
    guides(col=guide_legend(title =NULL),
           fill=guide_legend(title =NULL))+
    ylab("Incidence Rate\n per 100000")+
    theme_bw()
  
  
  dygraph(data_use_Runin_xts,xlab ="Week",ylab="Incidence Rate\n per 100000")%>%
    dySeries("observed",fillGraph=F,color ="grey") %>% 
    dySeries("fitted",fillGraph=F,color ="blue2",label="Fitted") %>% 
    dySeries("fittedp25",fillGraph=F,color ="orange2",label="Fitted p2.5") %>% 
    dySeries("fittedp975",fillGraph=F,color ="orange3",label="Fitted p97.25") %>% 
    dySeries("threshold",fillGraph=T,color ="purple",label ="Endemic channel") %>% 
    dySeries("observed_alarm",fillGraph=T,color ="red",label ="Alarm",
             drawPoints=T,pointSize =2,pointShape="circle") %>% 
    dyRangeSelector() %>% 
    dyLegend(show = "onmouseover") %>% 
    dyHighlight(highlightCircleSize =2, 
                highlightSeriesBackgroundAlpha = 0.2,
                hideOnMouseOut = F)
  
  
  dat_Sensitivity<-all_cv |> 
    dplyr::select(district,year,week,Cases,mean_rate,sd_rate,week_Interval,Pop,mean,lci,uci) |> 
    dplyr::mutate(obs_rate=(Cases/Pop)*1e5,
                  p25=(lci/Pop)*1e5,
                  p975=(uci/Pop)*1e5,
                  predicted=(mean/Pop)*1e5,
                  Threshold=mean_rate+(sd_rate*Z_Value)
    ) |> 
    dplyr::filter(week_Interval=="04")
  
  Combined_sensitivy<-dat_Sensitivity |> 
    dplyr::left_join(y.PREDS,by=c("year","week","week_Interval")) |> 
    dplyr::rename(pred_Cases=value) |> 
    dplyr::mutate(pred_rate=(pred_Cases/Pop)*1e5,
                  outbreak=as.numeric(obs_rate>Threshold),
                  exceed=as.numeric(pred_rate>Threshold)) 
  
  
  
  probs_Exceed<-Combined_sensitivy |> 
    dplyr::group_by(district,year,week,week_Interval) |> 
    dplyr::summarise(.groups ="drop",
                     outbreak=mean(outbreak),
                     total=n(),
                     total_Exceed=sum(exceed),
                     exceed_prob=mean(exceed))
  
  
  
  data_use_<-dat_Sensitivity |> 
    dplyr::left_join(probs_Exceed,by=c("district","year","week"))|> 
    dplyr::mutate(observed1=(Cases/Pop)*1e5,
                  observed=case_when(is.na(observed1)~0,
                                     TRUE~observed1),
                  observed_alarm=case_when(outbreak==1~observed,
                                           TRUE~as.numeric(NA)))
  
  cat("computed probs \n")
  print(data_use_$exceed_prob)
  idx.comp<-which(!is.na(data_use_$outbreak))
  
  roc_try<-try(reportROC(gold=as.numeric(data_use_$outbreak)[idx.comp],
                         predictor=data_use_$exceed_prob[idx.comp]),outFile =warning("ROC_error.txt"))
  
  roc_tab_names<-c("Cutoff","AUC","AUC.SE","AUC.low","AUC.up","P","ACC",
                   "ACC.low","ACC.up","SEN","SEN.low","SEN.up",
                   "SPE","SPE.low","SPE.up","PLR","PLR.low",
                   "PLR.up","NLR","NLR.low","NLR.up","PPV",
                   "PPV.low","PPV.up","NPV","NPV.low","NPV.up")
  
  
  
  kdd<-data.frame(t(rep(as.character(NA),length(roc_tab_names))))
  names(kdd)<-roc_tab_names
  
  if(class(roc_try) %in% c("NULL","try-error")){
    roc_report<-kdd
  }else{
    roc_report<-reportROC(gold=as.numeric(data_use_$outbreak)[idx.comp],
                          predictor=data_use_$exceed_prob[idx.comp])
  }
  
  if(roc_report$Cutoff%in% c(NA,-Inf,NaN,Inf)){
    sens_ppv<-tribble(~var,~val,~CI_Lower,~CI_Upper,
                      "Cutoff probability",roc_report$Cutoff,NA,NA,
                      "Area under the Curve (AUC)",roc_report$AUC,roc_report$AUC.low,roc_report$AUC.up,
                      "Accuracy",roc_report$ACC ,roc_report$ACC.low,roc_report$ACC.up,
                      "Sensitivity",roc_report$SEN,roc_report$SEN.low,roc_report$SEN.up,
                      "Specificity",roc_report$SPE,roc_report$SPE.low,roc_report$SPE.up,
                      "Positive Predictive Value (PPV)",roc_report$PPV,roc_report$PPV.low,roc_report$PPV.up,
                      "Negative Predictive Value (NPV)",roc_report$NPV,roc_report$NPV.low,roc_report$NPV.up)
    
    data_use_a<-data_use_ %>% 
      dplyr::mutate(prob_exceed=exceed_prob,
                    cutoff=NA,
                    validation_alarm=as.numeric(NA))
    
  }else{
    sens_ppv<-tribble(~var,~val,~CI_Lower,~CI_Upper,
                      "Cutoff probability",roc_report$Cutoff,NA,NA,
                      "Area under the Curve (AUC)",roc_report$AUC,roc_report$AUC.low,roc_report$AUC.up,
                      "Accuracy",roc_report$ACC ,roc_report$ACC.low,roc_report$ACC.up,
                      "Sensitivity",roc_report$SEN,roc_report$SEN.low,roc_report$SEN.up,
                      "Specificity",roc_report$SPE,roc_report$SPE.low,roc_report$SPE.up,
                      "Positive Predictive Value (PPV)",roc_report$PPV,roc_report$PPV.low,roc_report$PPV.up,
                      "Negative Predictive Value (NPV)",roc_report$NPV,roc_report$NPV.low,roc_report$NPV.up)  
    
    data_use_a<-data_use_ %>% 
      dplyr::mutate(prob_exceed=exceed_prob,
                    cutoff=as.numeric(roc_report$Cutoff),
                    validation_alarm=case_when((prob_exceed>=cutoff)~prob_exceed,
                                               TRUE~as.numeric(NA)))
  }
  
  #data_test_ggplot<<-data_use_a
  ratio_scale<-max(data_use_a$p975,na.rm =T)/max(data_use_a$prob_exceed,na.rm =T)
  
  
  data_use_AA<-data_use_a %>% 
    dplyr::mutate(Trend=1:n(),
                  lab_week=paste0(year,'_',str_pad(week,width = 2,side="left",pad='0')),
                  ratio_scale_p=ratio_scale) %>% 
    dplyr::rename(threshold=Threshold)
  
  Num_YYears<-length(unique(data_use_AA$year))
  breaks_p<-seq(1,nrow(data_use_AA),4*Num_YYears)
  
  
  val.plot1<-ggplot(aes(x=Trend),data=data_use_AA)+
    geom_line(aes(x=Trend,y=observed,col="Observed"),linewidth=0.82)+
    geom_line(aes(x=Trend,y=predicted,col='Predicted'),linewidth=1.2,lty=1)+
    geom_line(aes(x=Trend,y=threshold),linewidth=0.5,lty=1,col="blue",show.legend =F)+
    geom_area(aes(x=Trend,y=threshold,fill='Endemic Channel'),alpha=0.6)+
    geom_point(aes(x=Trend,y=observed_alarm,col="Outbreak"),size=3)+
    geom_ribbon(aes(ymin=p25,ymax=p975,
                    fill="95 % CI"),alpha=0.2)+
    geom_point(aes(x=Trend,y=validation_alarm*ratio_scale,col="Alarm"),size=3)+
    geom_line(aes(x=Trend,y=prob_exceed*ratio_scale,col="Excedance Probability"),linewidth=1)+
    
    geom_line(aes(x=Trend,y=cutoff*ratio_scale,col="Cutoff Prob"),linewidth=1.2)+
    scale_y_continuous(name = "Incidence Rate\n per 100000",sec.axis =sec_axis(~ . /ratio_scale,name="Probability"))+
    scale_x_continuous(breaks=breaks_p,labels =data_use_AA$lab_week[breaks_p])+
    
    scale_color_manual(values=c("Observed"='#00336FFF',
                                "Predicted"='#A72197FF',
                                "Cutoff Prob"="red",
                                "Excedance Probability"="yellowgreen",
                                #"Endemic"='lightblue2',
                                "Outbreak"='orange2',
                                "Alarm"='blue'))+
    scale_fill_manual(values=c("Endemic Channel"='lightblue2',
                               "95 % CI"=grey(0.3)))+
    ggtitle(paste('District:',district_validation))+
    guides(col=guide_legend(title =NULL),
           fill=guide_legend(title =NULL))+
    ylab("DIR")+
    xlab("Year Week")+
    theme_bw()
  
  year_VAL<-sort(unique(data_use_AA$year))
  date_week<-seq.Date(as.Date(paste0(min(year_VAL),'-01-01')),as.Date(paste0(max(year_VAL),'-12-31')),by='week')[-1]
  
  data_use_b<-data_use_a %>% 
    dplyr::select(predicted,observed,Threshold,
                  cutoff,prob_exceed,validation_alarm)%>% 
    dplyr::rename(threshold=Threshold)
  
  data_use_xts<-xts(data_use_b,order.by =date_week,
                    frequency=7)
  
  dygraph(data_use_xts,xlab ="Week",ylab="Incidence Rate\n per 100000")%>%
    dySeries("prob_exceed",col="blue",stepPlot = F,axis="y2",label="Prob exceed") %>% 
    dySeries("cutoff",col="red",stepPlot = F,axis="y2",label="Cutoff") %>% 
    dySeries("observed",fillGraph=F,color ="yellowgreen") %>% 
    dySeries("validation_alarm",fillGraph=F,color ="orange4",drawPoints=T,
             pointSize =2,pointShape ="circle",axis="y2") %>% 
    dySeries("threshold",fillGraph=T,color ="purple",label ="Endemic channel") %>% 
    dyRangeSelector() %>% 
    dyLegend(show = "onmouseover") %>% 
    dyHighlight(highlightCircleSize =2, 
                highlightSeriesBackgroundAlpha = 0.2,
                hideOnMouseOut = F)
  
  ## Sensitivity Table
  
  distr_n<-district_validation
  sen_spec_cmd<-paste(c("function() { sens_ppv","kbl(format='html',caption = paste('District ',distr_n))","kable_styling('striped', full_width = F)",
                        "column_spec(2,background='#94a323')"),collapse ='%>%\n')
  
  
  sen_spec_cmd<-paste(sen_spec_cmd,'}\n',collapse ='')
  
  border_prop<-officer::fp_border(width=0.5)
  
  
  sens_ppv |> 
    flextable::qflextable() |> 
    flextable::font(part = "all", fontname = "Arial") |> 
    flextable::border_inner_h(border =border_prop) |> 
    flextable::padding(part="body",padding = 2) |> 
    flextable::set_header_labels(var="",
                                 val="",
                                 CI_Lower="Lower",
                                 CI_Upper="Upper") |> 
    flextable::add_header_row(values=c(NA,"CI"),colwidths =c(2,2)) |> 
    flextable::align(align ="center",part ="header") |> 
    flextable::align(j=2:4,align ="center",part ="body") |> 
    flextable::bg(i=c(1,2,4,5),j=2,bg="#CCBB44") |> 
    flextable::bg(i=1:2,part="header",bg='grey90') |> 
    flextable::border_remove() |> 
    flextable::hline() |> 
    flextable::hline_top() |> 
    flextable::htmltools_value()
  
  
  
  ## save Output objects for Book compilation
  
  Descriptive_table1<-tab_Dat |> 
    as_flextable() |> 
    #flextable::autofit(add_w=0,add_h=10,unit='mm',part='body') |> 
    flextable::set_caption(as_paragraph(paste('District ',district_new)),
                           fp_p=officer::fp_par(text.align = "left")) |> 
    flextable::fit_to_width(max_width =9,unit='in') |> 
    flextable::fontsize(part='header',size=12) |> 
    flextable::fontsize(part='body',size=9) |> 
    flextable::font(part='all',fontname ="Arial") |> 
    flextable::padding(part="body",padding = 2) |> 
    flextable::bold(i=1,part ="header") |> 
    flextable::border_inner_h(border =border_prop) |> 
    flextable::color(i=1,color="#CCBB44",part="header") |> 
    flextable::bg(j=16,bg="#94a323") |> 
    flextable::align(part='body',align ="center") |> 
    flextable::border_remove() |> 
    flextable::hline() |> 
    flextable::hline_top() |> 
    flextable::htmltools_value()
  
  Descriptive_plots<-plot_List0
  
  Time_series_Plots<-all_xts_Plots
  
  Spatial_Plots<-plot_List
  
  if(Run_Dlnm){
    
    Lag_contour_Plots<-all_cont_plots
    
    Plot_data_lags_slice_size<-unlist(foreach(aa=1:length(all_lag_slice_plots))%do%nrow(all_lag_slice_plots[[aa]]$data))
    Idx_Good<-which(Plot_data_lags_slice_size>0)
    
    
    Lag_slice_Plots<-all_lag_slice_plots[Idx_Good]
  }
  
  Seasonality<-seasonal_plot
  
  Model_lag_selection<-tab_Dat_lag |> 
    as_flextable() |> 
    #flextable::autofit(add_w=0,add_h=10,unit='mm',part='body') |> 
    flextable::set_caption(as_paragraph(paste('District ',district_new)),
                           fp_p=officer::fp_par(text.align = "left")) |> 
    flextable::fit_to_width(max_width =12,unit='in') |> 
    flextable::fontsize(part='header',size=12) |> 
    flextable::fontsize(part='body',size=9) |> 
    flextable::font(part='all',fontname ="Arial") |> 
    flextable::padding(part="body",padding = 2) |> 
    flextable::bold(i=1,part ="header") |> 
    flextable::border_inner_h(border =border_prop) |> 
    flextable::color(i=1,color="#CCBB44",part="header") |> 
    flextable::bg(i=rows_01,j=2:16,bg="#4477AA",part="body") |> 
    flextable::border_remove() |> 
    flextable::align(part='body',align ="center") |> 
    flextable::hline() |> 
    flextable::hline_top() |> 
    flextable::htmltools_value()
  
  Runin_plot<-plot.runin
  
  Runin_plot_xts<-dygraph(data_use_Runin_xts,xlab ="Week",ylab="Incidence Rate\n per 100000")%>%
    dySeries("observed",fillGraph=F,color ="grey") %>% 
    dySeries("fitted",fillGraph=F,color ="blue2",label="Fitted") %>% 
    dySeries("fittedp25",fillGraph=F,color ="orange2",label="Fitted p2.5") %>% 
    dySeries("fittedp975",fillGraph=F,color ="orange3",label="Fitted p97.25") %>% 
    dySeries("threshold",fillGraph=T,color ="purple",label ="Endemic channel") %>% 
    dySeries("observed_alarm",fillGraph=T,color ="red",label ="Alarm",
             drawPoints=T,pointSize =2,pointShape="circle") %>% 
    dyRangeSelector() %>% 
    dyLegend(show = "onmouseover") %>% 
    dyHighlight(highlightCircleSize =2, 
                highlightSeriesBackgroundAlpha = 0.2,
                hideOnMouseOut = F)
  
  Runin_Plots<-list(Runin_plot=Runin_plot,
                    Runin_plot_xts=Runin_plot_xts)
  
  Eval_plot<-val.plot1
  
  Eval_plot_xts<-dygraph(data_use_xts,xlab ="Week",ylab="Incidence Rate\n per 100000")%>%
    dySeries("prob_exceed",col="blue",stepPlot = F,axis="y2",label="Prob exceed") %>% 
    dySeries("cutoff",col="red",stepPlot = F,axis="y2",label="Cutoff") %>% 
    dySeries("observed",fillGraph=F,color ="yellowgreen") %>% 
    dySeries("validation_alarm",fillGraph=F,color ="orange4",drawPoints=T,
             pointSize =2,pointShape ="circle",axis="y2") %>% 
    dySeries("threshold",fillGraph=T,color ="purple",label ="Endemic channel") %>% 
    dyRangeSelector() %>% 
    dyLegend(show = "onmouseover") %>% 
    dyHighlight(highlightCircleSize =2, 
                highlightSeriesBackgroundAlpha = 0.2,
                hideOnMouseOut = F)
  
  Eval_Plots<-list(Eval_plot=Eval_plot,
                   Eval_plot_xts=Eval_plot_xts)
  
  Roc_table<-sens_ppv |> 
    flextable::qflextable() |> 
    flextable::font(part = "all", fontname = "Arial") |> 
    flextable::border_inner_h(border =border_prop) |> 
    flextable::padding(part="body",padding = 2) |> 
    flextable::set_header_labels(var="",
                                 val="",
                                 CI_Lower="Lower",
                                 CI_Upper="Upper") |> 
    flextable::add_header_row(values=c(NA,"CI"),colwidths =c(2,2)) |> 
    flextable::align(align ="center",part ="header") |> 
    flextable::align(j=2:4,align ="center",part ="body") |> 
    flextable::bg(i=c(1,2,4,5),j=2,bg="#CCBB44") |> 
    flextable::bg(i=1:2,part="header",bg='grey90') |> 
    flextable::border_remove() |> 
    flextable::hline() |> 
    flextable::hline_top() |> 
    flextable::htmltools_value()
  
  data_one<-shiny_obj1$data_one
  Lag_dic_comp1<-shiny_obj1$Lag_dic_comp1
  Lag_combinations_dic1<-shiny_obj1$Lag_combinations_dic1
  
  levels_Rank<-sort(str_pad(unique(Lag_dic_comp1$Rank),width=2,pad=0,side="left"))
  levels_Var<-Lag_dic_comp1$var
  
  Lag_dic_comp2<-Lag_dic_comp1 |> 
    dplyr::mutate(DIC=round(DIC,3),
                  coeff=round(coeff,3),
                  low=round(low,3),
                  high=round(high,3),
                  logcpo=round(logcpo,3),
                  Rank=str_pad(Rank,width=2,pad=0,side="left"),
                  var=factor(var,levels=levels_Var))
  
  Lag_dic_comp1_Long<-reshape2::melt(Lag_dic_comp2,c("var","Variable"))
  
  
  all_vars<-c(base_vars,number_of_cases,pop.var.dat,alarm_indicators)
  
  
  dat_Sel<-data_augmented[,all_vars]
  
  sens_ppv<-sens_ppv
  
  Plot_drr<-st_as_sf(all_Plot_Poly$Cases)
  
  all_Plot_Poly_sf<-lapply(all_Plot_Poly, st_as_sf)
  
  selected_zvalue_pros0<-shiny_obj1$selected_zvalue
  Selected_out_threshold0<-as.numeric(shiny_obj1$zvalue_sel_Ordered[1,"Cutoff"])
  
  selected_zvalue_pros<-ifelse(is.na(selected_zvalue_pros0),1.2,selected_zvalue_pros0)
  Selected_out_threshold<-ifelse(is.na(Selected_out_threshold0),0.1,Selected_out_threshold0)
  
  alarm_vars_pros<-shiny_obj1$alarm_vars
  
  Selected_lag_Vars_pros<-shiny_obj1$Selected_lag_Vars
  
  Computed_pred_Distance<-floor(mean(as.numeric(unlist(str_extract_all(Selected_lag_Vars_pros,"[:number:]+")))))
  
  meta_Prediction<-tribble(~var,~Value,
                           "Alarm indicators",paste0(alarm_vars_pros,collapse ='\n'),
                           "Selected lags",paste0(Selected_lag_Vars_pros,collapse ='\n'),
                           "Prediction distance",paste0(as.character(Computed_pred_Distance),' Weeks'),
                           "Z outbreak",as.character(selected_zvalue_pros),
                           "Alarm threshold",as.character(Selected_out_threshold),
                           
  )
  
  factor_vars<-c("Alarm indicators",
                 "Selected lags",
                 "Prediction distance",
                 "Z outbreak",
                 "Alarm threshold")
  
  meta_Prediction1<-meta_Prediction |> 
    dplyr::mutate(var=factor(var,levels=factor_vars),
                  id=1)
  
  meta_Prediction_wide<-meta_Prediction1 |> 
    dplyr::group_by(id) |> 
    tidyr::spread(var,'Value') |> 
    dplyr::ungroup() |> 
    dplyr::select(-id)
  
  ewars_json_Objects<-list(Lag_selection_table=Lag_dic_comp2,
                           Selected_Lag_Combination=Lag_combinations_dic1,
                           Sensitivity_Specificity_Table=sens_ppv,
                           Runin_period_data=data_plot_RuninB1,
                           Runin_period_data_xts=data_use_Runin_xts,
                           Validation_data=data_use_AA,
                           Validation_data_xts=data_use_xts,
                           Spatial_plot_data=all_Plot_Poly_sf,
                           seasonal_plot_data=seasonal_plot$data,
                           meta_Prediction=meta_Prediction1[,-3],
                           Surveillance_data=dat_Sel)
  
  
  
  ewars_json_Objects_json<-toJSON(ewars_json_Objects)
  
  grob_Fun<-function(p_lot){
    if(class(p_lot)[1]=="gg"){
      ggplot2::ggplotGrob(p_lot)
    }else{
      p_lot
    }
  }
  
  #grob_Fun(Descriptive_plots[[1]][[1]])
  
  Descriptive_plots_Grobs<-lapply(Descriptive_plots, FUN =function(x) grob_Fun(x))
  if(Run_Dlnm){
    Lag_contour_Plots_Grobs<-lapply(Lag_contour_Plots, FUN =function(x) grob_Fun(x))
    Lag_slice_Plots_Grobs<-lapply(Lag_slice_Plots, FUN =function(x) grob_Fun(x))
  }
  #Seasonality_Grobs<-grob_Fun(Seasonality)
  Seasonality_Grobs<-Seasonality
  
  Runin_plot_Grobs<-lapply(Runin_Plots, FUN =function(x) grob_Fun(x))
  Eval_plot_Grobs<-lapply(Eval_Plots, FUN =function(x) grob_Fun(x))
  
  
  # For_book0<-list(Descriptive_table1=Descriptive_table1,
  #                Descriptive_plots=Descriptive_plots,
  #                Time_series_Plots=Time_series_Plots,
  #                Spatial_Plots=Spatial_Plots,
  #                Lag_contour_Plots=Lag_contour_Plots,
  #                Lag_slice_Plots=Lag_slice_Plots,
  #                Seasonality=Seasonality,
  #                Model_lag_selection=Model_lag_selection,
  #                Runin_plot=Runin_Plots,
  #                #Runin_plot_xts=Runin_plot_xts,
  #                Eval_plot=Eval_Plots,
  #                #Eval_plot_xts=Eval_plot_xts,
  #                Roc_table=Roc_table,
  #                ratio_scale=ratio_scale)
  
  if(Run_Dlnm){
    For_book<-list(Descriptive_table1=Descriptive_table1,
                   Descriptive_plots=Descriptive_plots_Grobs,
                   Time_series_Plots=Time_series_Plots,
                   Spatial_Plots=Spatial_Plots,
                   Lag_contour_Plots=Lag_contour_Plots_Grobs,
                   Lag_slice_Plots=Lag_slice_Plots_Grobs,
                   Seasonality=list(Seasonality_Grobs),
                   Model_lag_selection=Model_lag_selection,
                   Runin_plot=Runin_plot_Grobs,
                   #Runin_plot_xts=Runin_plot_xts,
                   Eval_plot=Eval_plot_Grobs,
                   #Eval_plot_xts=Eval_plot_xts,
                   Roc_table=Roc_table,
                   ratio_scale=ratio_scale)
  }else{
    For_book<-list(Descriptive_table1=Descriptive_table1,
                   Descriptive_plots=Descriptive_plots_Grobs,
                   Time_series_Plots=Time_series_Plots,
                   Spatial_Plots=Spatial_Plots,
                   # Lag_contour_Plots=Lag_contour_Plots_Grobs,
                   # Lag_slice_Plots=Lag_slice_Plots_Grobs,
                   Seasonality=list(Seasonality_Grobs),
                   Model_lag_selection=Model_lag_selection,
                   Runin_plot=Runin_plot_Grobs,
                   #Runin_plot_xts=Runin_plot_xts,
                   Eval_plot=Eval_plot_Grobs,
                   #Eval_plot_xts=Eval_plot_xts,
                   Roc_table=Roc_table,
                   ratio_scale=ratio_scale)
  }
  
  
  
  
  #report_pth<-file.path(out_Path,"Report_objs",paste0("District_",dist_padded))
  path_mk<-file.path(reporT_pAth,"Markdown")
  
  #if(!dir.exists(report_pth)) dir.create(report_pth,recursive =T)
  if(!dir.exists(path_mk)) dir.create(path_mk,recursive =T)
  
  # copy _quarto.yml to path_mk
  
  #file.copy("./app/_quarto.yml",path_mk,overwrite =T)
  
  file.copy("_quarto.yml",path_mk,overwrite =T)
  
  suppressWarnings(saveRDS(For_book,file.path(reporT_pAth,"report_obj.rds"),compress =T))
  
  #suppressWarnings(saveRDS(For_book0,file.path(reporT_pAth,"report_obj_original.rds"),compress =T))
  
  write(ewars_json_Objects_json,file.path(reporT_pAth,"ewars_Output_Objects.json"))
  
  ## create rmarkdown Files
  
  #header_fl<-"./app/book_header_File.qmd"
  #header_fl<-"book_header_File.qmd"
  header_fl<-"book_header_File.txt"
  
  
  heade_File<-read.csv(header_fl)
  names(heade_File)<-"var"
  
  
  
  names(For_book)
  
  n_Descriptive_plots<-length(For_book$Descriptive_plots)
  n_Time_series_Plots<-length(For_book$Time_series_Plots)
  n_Spatial_Plots<-length(For_book$Spatial_Plots)
  n_Lag_contour_Plots<-length(For_book$Lag_contour_Plots)
  n_Lag_slice_Plots<-length(For_book$Lag_slice_Plots)
  n_Runin_plot<-length(For_book$Runin_plot)
  n_Eval_plot<-length(For_book$Eval_plot)
  
  if(Run_Dlnm){
    
    tribble_Meta_qmd<-tribble(~var,~type,~header_name,~N,
                              "Descriptive_table1","Table","# Descriptive table {#sec-Summary_tables}",1,
                              "Descriptive_plots","Plot","# Descriptive Plots {#sec-Summary_plots}",n_Descriptive_plots,
                              "Time_series_Plots","Plot","# Time series Plots {#sec-Summary_plots}",n_Time_series_Plots,
                              "Spatial_Plots","Plot","# Spatial  Plots {#sec-spat}",n_Spatial_Plots,
                              "Lag_contour_Plots","Plot","# Lag contour  Plots {#sec-lag}",n_Lag_contour_Plots,
                              "Lag_slice_Plots","Plot","# Lag Slices  Plots {#sec-lag}",n_Lag_slice_Plots,
                              "Seasonality","Plot","# Seasonality {#sec-seas}",1,
                              "Model_lag_selection","Table","# lag selection {#sec-model}",1,
                              "Runin_plot","Plot","# Runin Plot {#sec-model}",n_Runin_plot,
                              "Eval_plot","Plot","# Evaluation Plot {#sec-model}",n_Eval_plot,
                              "Roc_table","Table","# Sensitivy & Specificty {#sec-model}",1,
    )
    
  }else{
    tribble_Meta_qmd<-tribble(~var,~type,~header_name,~N,
                              "Descriptive_table1","Table","# Descriptive table {#sec-Summary_tables}",1,
                              "Descriptive_plots","Plot","# Descriptive Plots {#sec-Summary_plots}",n_Descriptive_plots,
                              "Time_series_Plots","Plot","# Time series Plots {#sec-Summary_plots}",n_Time_series_Plots,
                              "Spatial_Plots","Plot","# Spatial  Plots {#sec-spat}",n_Spatial_Plots,
                              # "Lag_contour_Plots","Plot","# Lag contour  Plots {#sec-lag}",n_Lag_contour_Plots,
                              # "Lag_slice_Plots","Plot","# Lag Slices  Plots {#sec-lag}",n_Lag_slice_Plots,
                              "Seasonality","Plot","# Seasonality {#sec-seas}",1,
                              "Model_lag_selection","Table","# lag selection {#sec-model}",1,
                              "Runin_plot","Plot","# Runin Plot {#sec-model}",n_Runin_plot,
                              "Eval_plot","Plot","# Evaluation Plot {#sec-model}",n_Eval_plot,
                              "Roc_table","Table","# Sensitivy & Specificty {#sec-model}",1,
    )
  }
  
  #mm<-8
  
  for (mm in 1:nrow(tribble_Meta_qmd)){
    
    tribble_Meta_qmd_Sub<-tribble_Meta_qmd[mm,]
    
    quarto_cmd0<-tribble(~var,
                         tribble_Meta_qmd_Sub$header_name,
                         " ",
                         "```{r}")
    
    quarto_cmd1<-tribble(~var,
                         paste0('report_pth<-"',reporT_pAth,'"'),
                         paste0('report_Obj<-readRDS(file.path(report_pth,"report_obj.rds"))'),
                         #paste0('Descriptive_table1<-report_Obj$Descriptive_table1'),
                         paste0(tribble_Meta_qmd_Sub$var,'<-report_Obj$',tribble_Meta_qmd_Sub$var),
                         "ratio_scale<-report_Obj$ratio_scale",
                         "```"
    )
    
    quarto_cmd2<-tribble(~var,
                         " ",
                         " ",
                         "```{r}",
                         "#| echo: false",
                         "#| message: false",
                         "#| warning: false",
                         "#| comment: ' '" ,
    )
    
    plot_layout_cmd<-tribble(~var,
                             "#| layout-ncol: 2"
    )
    
    plot_fig_width<-tribble(~var,
                            "#| fig-width: 13" ,
                            "#| out-width: 13in" ,
    )
    
    # determine the output the tribble
    
    if(tribble_Meta_qmd_Sub$type=="Table"){
      quarto_cmd3<-tribble(~var,
                           tribble_Meta_qmd_Sub$var  
      )
    }else if(tribble_Meta_qmd_Sub$type=="Plot"){
      
      if(tribble_Meta_qmd_Sub$N>0){
        
        plot_Con<-function(bb){
          
          var_Plot0<-paste0(tribble_Meta_qmd_Sub$var,"[[",bb,"]]")
          
          tribble(~var,
                  paste0("if(class(",var_Plot0,")[1]=='gtable'){"),
                  paste0("plot(",var_Plot0,")"),
                  "}else{",
                  var_Plot0,
                  "}"
          )
        }
        quarto_cmd3_0<-foreach(aa=1:tribble_Meta_qmd_Sub$N,.combine =rbind)%do% plot_Con(aa)
        
      }else{
        var_Plot0<-tribble_Meta_qmd_Sub$var
        
        quarto_cmd3_0<-tribble(~var,
                               paste0("if(class(",var_Plot0,")[1]=='gtable'){"),
                               paste0("plot(",var_Plot0,")"),
                               "}else{",
                               var_Plot0,
                               "}"
        )
        
      }
      
      if(tribble_Meta_qmd_Sub$var%in% c("Descriptive_plots","Spatial_Plots","Lag_contour_Plots","Lag_slice_Plots")){
        quarto_cmd3<-rbind(plot_layout_cmd,quarto_cmd3_0)
      }else if(tribble_Meta_qmd_Sub$var%in% c("Runin_plot","Eval_plot")){
        quarto_cmd3<-rbind(plot_fig_width,quarto_cmd3_0)
      }else{
        quarto_cmd3<-quarto_cmd3_0
      }
    }
    quarto_Last<-tribble(~var,
                         "```")
    
    unlink(file.path(path_mk,paste0( tribble_Meta_qmd_Sub$var,'.qmd')))
    
    cat(c(quarto_cmd0$var,
          heade_File$var,
          quarto_cmd1$var,
          quarto_cmd2$var,
          quarto_cmd3$var,
          quarto_Last$var),
        file =file.path(path_mk,paste0( tribble_Meta_qmd_Sub$var,'.qmd')),
        sep="\n")
    
    
    
    
  }
  # organize the report into section
  if(Run_Dlnm){
  tribble_Sections<-tribble(~var,~type,~header_name,~N,
                            "index","text","# Ewars output {.unnumbered}",1,
                            "Descriptive_Stats","text","# Descriptive Summaries {.unnumbered}",1,
                            "Lag_analysis","text","# Lag non linear analysis {.unnumbered}",1,
                            "model_Selection","text","# Model selection  {.unnumbered}",1,
                            
  )
  }else{
    tribble_Sections<-tribble(~var,~type,~header_name,~N,
                              "index","text","# Ewars output {.unnumbered}",1,
                              "Descriptive_Stats","text","# Descriptive Summaries {.unnumbered}",1,
                              #"Lag_analysis","text","# Lag non linear analysis {.unnumbered}",1,
                              "model_Selection","text","# Model selection  {.unnumbered}",1,
                              
    )
  }
  
  for (ss in 1:nrow(tribble_Sections)){
    
    tribble_Sections_Sub<-tribble_Sections[ss,]
    
    quarto_cmd0<-tribble(~var,
                         tribble_Sections_Sub$header_name,
                         " ")
    cat(quarto_cmd0$var,
        file =file.path(path_mk,paste0( tribble_Sections_Sub$var,'.qmd')),
        sep="\n")
    
  }
  
  
  ## organize the qmd documnets
  
  if(Run_Dlnm){
  
  qmd_order<-c("index",
               "Descriptive_Stats",
               "Descriptive_table1",
               "Descriptive_plots",
               "Time_series_Plots",
               "Spatial_Plots",
               "Lag_analysis",
               "Lag_contour_Plots",
               "Lag_slice_Plots",
               "Seasonality",
               "model_Selection",
               "Model_lag_selection",
               "Runin_plot",
               "Eval_plot",
               "Roc_table"
  )
  
  }else{
    qmd_order<-c("index",
                 "Descriptive_Stats",
                 "Descriptive_table1",
                 "Descriptive_plots",
                 "Time_series_Plots",
                 "Spatial_Plots",
                 #"Lag_analysis",
                 #"Lag_contour_Plots",
                 #"Lag_slice_Plots",
                 "Seasonality",
                 "model_Selection",
                 "Model_lag_selection",
                 "Runin_plot",
                 "Eval_plot",
                 "Roc_table"
    )
  }
  cat(paste0('- ',qmd_order,'.qmd',sep='\n'))
  
  
  #?quarto_render
  quarto::quarto_render(input=path_mk,as_job=F)
  
}
