# plumber.R

source("load_packages.R",local =T)

get_D_ata<-function(p){
  if(str_detect(p,".xlsx$")){
    data <- data.frame(read_xlsx(p,sheet=1),stringsAsFactors =F)
  }
  else if(str_detect(p,".xls$")){
    data <- data.frame(read_xls(p,sheet=1),stringsAsFactors =F)
  } 
  else if(str_detect(p,".csv$")){
    data <- read.csv(p,header =T,stringsAsFactors =F)
  } else{
    data <- data.frame(read_xlsx("Demo_Data.xlsx",sheet=1),stringsAsFactors =F)
  }
  data
}

main_path<-getwd()
surv_path<-file.path(main_path,"Demo_data")
SHP_path<-file.path(main_path,"Demo_data","Shape_file_Demo")

base_vars<-c("district","year","week")
#*@post /Ewars_run
#*@apiTitle Upload file and run DBI
#* @param  csv_File:file
#* @param  shape_File:file
#* @param  config_File:file
#* @parser csv list(show_col_types=FALSE)
#* @parser all
##*@serializer csv

function(req) 
  {
  
  mp_f<-mime::parse_multipart(req)
  print(mp_f)
  surv_dat<-read.csv(mp_f$csv_File$datapath)
  shape_fl<-st_read(mp_f$shape_File$datapath)
  demo_shp_ter<-terra::vect(shape_fl)
  config_fl<-jsonify::from_json(mp_f$config_File$datapath)
  
  ## make all config variables available to the API
  configVars<-c("alarm_variables",
                "other_alarm_variables",
                "number_of_cases_var",
                "population_var",
                "nlag",
                "generate_DBI_report_html",
                "generate_DBII_report_html")
  
  for (ww in 1:length(configVars)){
    assign(configVars[ww],config_fl[[configVars[ww]]])
  }
  
  
  surv_Dat_dir<-"./ewars_Files/surveillance_data"
  Pros_Dat_dir<-"./ewars_Files/prospective_data"
  SHP_fl_dir<-"./ewars_Files/shape_files"
  Output_dir<-"./ewars_Files/outputs"
  surv_name<-"Surveillance_Data.csv"
  shape_fl<-"district_ShapeFile.GeoJSON"
  
  if(!dir.exists(surv_Dat_dir)) dir.create(surv_Dat_dir,recursive =T)
  if(!dir.exists(Pros_Dat_dir)) dir.create(Pros_Dat_dir,recursive =T)
  if(!dir.exists(SHP_fl_dir)) dir.create(SHP_fl_dir,recursive =T)
  if(!dir.exists(Output_dir)) dir.create(Output_dir,recursive =T)
  
  write.csv(surv_dat,file.path(surv_Dat_dir,surv_name),row.names =F)
  
  terra::writeVector(demo_shp_ter,
                     filename =file.path(SHP_fl_dir,shape_fl),
                     filetype="GeoJSON",
                     overwrite=T)
  
  
  out_path<-Output_dir
  
  data<-get_D_ata(file.path(surv_Dat_dir,surv_name))
  
  pp<-sf::st_read(file.path(SHP_fl_dir,shape_fl)) |> 
    sf::as_Spatial()
  
  disTricts<-unique(data$district)
  disTricts_SHP<-unique(as.numeric(pp$district))
  
  districts_shape<-disTricts[which(disTricts%in%disTricts_SHP)]
  
  dat_A_<-data |>  
    dplyr::arrange(district,year,week) %>% 
    dplyr::filter(district %in% pp$district &!week==53) |> 
    dplyr::group_by(district,year,week) |> 
    dplyr::mutate(N=1:n()) |> 
    dplyr::filter(N==1) |> 
    dplyr::ungroup()
  
  dat_A<-dat_A_ |> 
    data.frame()
  
  beg.year<-min(dat_A$year)
  end.year<-max(dat_A$year)
  
  dat_dist<-expand.grid(week=1:52,
                        year=sort(unique(dat_A$year)),
                        district=sort(unique(dat_A$district))) %>% 
    dplyr::select(district,year,week)
  
  ## remove duplicates here 2024-04-01
  
  
  data_augmented<-merge(dat_dist,dat_A,by=c("district","year","week"),all.x=T,sort=T) %>% 
    dplyr::mutate(district_w=paste0(district,'_',week)) %>% 
    dplyr::arrange(district,year,week)
  
  vars<-names(dat_A)
  
  var_Sele<-c(base_vars,number_of_cases_var,population_var,alarm_variables)
  
  data_augmented0<-data_augmented |> 
    dplyr::select(all_of(var_Sele)) |> 
    dplyr::mutate(Cases=.data[[number_of_cases_var]],
                  Pop=.data[[population_var]],
                  log_Pop=log(.data[[population_var]]/1e5)) |> 
    data.frame()
  
  source("New_model_helper_Functions_v2.R",local =T)
  
  source("Lag_Model_selection_ewars_By_District_api.R",local =T)
  
  if(generate_DBI_report_html==1){
 source("Ewars_API_html_report.R",local =T)
  }
  #all_endemic
  
}

# extract certain values from the API after run

#* @get /sensitivity_specificty
#* @param district
#* @serializer json

function(district

) # boundary file in .shp format
{
  
  # 
  # surv_path<-as.character(surv_path)
  # shape_fl<-as.character(shape_fl)
  
  surv_Dat_dir<-"./ewars_Files/surveillance_data"
  SHP_fl_dir<-"./ewars_Files/shape_files"
  Output_dir<-"./ewars_Files/outputs"
  
  shiny_obj_Main_pth<-file.path(Output_dir,"For_Shiny")
  all_files_Path<-file.path(Output_dir,"For_Shiny","All_district")
  
  district_D<-as.numeric(district)
  district_validation<-district_D
  
  dist_padded<-str_pad(district_D,side="left",width=3,pad=0)
  shiny_obj_pth<-file.path(shiny_obj_Main_pth,paste0("District_",dist_padded))
  
  Districts_DBI_surve_Dat<- readRDS(file.path(all_files_Path,"Districts_DBI_surve_Dat.rds"))
  
  
  
  
  if(district_D %in% Districts_DBI_surve_Dat){
  
  
  get_Ojs<-function(){
    gc()
    readRDS(file.path(all_files_Path,"Shiny_Objs_all.rds"))
    
    
  }
  
  all_Objs<-get_Ojs()
  
  
  get_Ojs1<-function(){
    gc()
    readRDS(file.path(shiny_obj_pth,"Shiny_Objs.rds"))
    
    
  }
  
  
  shiny_obj1<-get_Ojs1()
  all_cv<-shiny_obj1[["all_cv"]]
  y.PREDS<-shiny_obj1[["y.PREDS"]]
  selected_zvalue<-shiny_obj1[["selected_zvalue"]]
  all_endemic<-all_Objs[["all_endemic"]]
  data_augmented<-all_Objs[["data_augmented"]]
  sel_var_endemic<-all_Objs[["sel_var_endemic"]]
  names_cov_Plot<-all_Objs[["names_cov_Plot"]]
  Z_Value<-selected_zvalue
  model_final_rw_fitted_Values<-shiny_obj1[["model_final_rw_fitted_Values"]]
  dat_kl_Long<-shiny_obj1[["dat_kl_Long"]]
  
  
  dat_A<-data_augmented %>% 
    dplyr::arrange(district,year,week) %>% 
    dplyr::filter(!week==53)
  
  ## balance the observations to compute expected cases correctly
  
  beg.year<-min(dat_A$year)
  end.year<-max(dat_A$year)
  
  
  new_model_Year_validation<-end.year
  
  
  for_endemic<-all_endemic |> 
    dplyr::filter(district==district_D) |> 
    dplyr::mutate(threshold_cases=mean_cases+Z_Value*(sd_cases),
                  threshold_rate=mean_rate+Z_Value*(sd_rate))
  
  dat_augmented_Sub<-data_augmented |> 
    dplyr::filter(district==district_D) |> 
    dplyr::arrange(district,year,week)
  
  dat.4.endemic<-dat_augmented_Sub[,sel_var_endemic]
  names(dat.4.endemic)<-c(base_vars,"cases","pop")
  
  idx_runin<-which(!dat_augmented_Sub$year>=new_model_Year_validation)
  
  
  runin_dat<-dat.4.endemic |> 
    dplyr::filter(!year>=new_model_Year_validation) |> 
    dplyr::mutate(observed_cases=cases,
                  observed_rate=(cases/pop)*1e5,
                  fitted=model_final_rw_fitted_Values$mean[idx_runin],
                  fitted=(fitted/pop)*1e5,
                  fittedp25=model_final_rw_fitted_Values$`0.025quant`[idx_runin],
                  fittedp25=(fittedp25/pop)*1e5,
                  fittedp975=model_final_rw_fitted_Values$`0.975quant`[idx_runin],
                  fittedp975=(fittedp975/pop)*1e5,
    ) %>% 
    dplyr::left_join(for_endemic,by=c("district","year","week")) |> 
    dplyr::mutate(
      #outbreak=observed_cases>threshold_cases,
      outbreak=observed_rate>threshold_rate,
      observed_alarm=case_when(outbreak==1~observed_rate,
                               TRUE~as.numeric(NA))) |> 
    dplyr::select(district,year,week,observed_rate,fitted,fittedp25,fittedp975,outbreak,threshold_rate,observed_alarm)
  
  cat(paste("district is<<>>",district_validation),'\n')
  
  end.runin.year<-new_model_Year_validation-1
  #date_week_runin<-seq.Date(as.Date(paste0(beg.year,'-01-01')),as.Date(paste0(end.runin.year,'-12-31')),by='week')[-1]
  #date_week_runin<-seq.Date(as.Date(paste0(beg.year,'-01-01')),as.Date(paste0(end.runin.year,'-12-31')),by='week')
  date_week_runin<-foreach(yr=sort(unique(runin_dat$year)),.combine =c)%do% seq.Date(as.Date(paste0(yr,'-01-01')),as.Date(paste0(yr,'-12-31')),by='week')
  
  
  
  data_Weeks_Runin_prev<-data.frame(date=date_week_runin,
                                    year_week=format.Date(date_week_runin,"%Y_%W"),
                                    year=year(date_week_runin),
                                    stringsAsFactors =F,
                                    week=week(date_week_runin)) %>% 
    mutate(Week=str_split_fixed(year_week,pattern ='_',n=2)[,2]) %>% 
    dplyr::filter(as.numeric(Week)%in% 1:52)
  
  data_Weeks_Runin<-data.frame(date=date_week_runin,
                               year_week=format.Date(date_week_runin,"%Y_%W"),
                               year=year(date_week_runin),
                               stringsAsFactors =F,
                               week=week(date_week_runin)) %>% 
    mutate(Week=str_split_fixed(year_week,pattern ='_',n=2)[,2]) |> 
    dplyr::select(-year_week)
  
  
  weeks.in.data_runin<-data_augmented %>% 
    dplyr::mutate(year_week=paste0(year,'-',str_pad(week,side ="left",pad =0,width =2))) 
  
  year_week_S_runin<-data_Weeks_Runin %>% dplyr::group_by(year,Week) %>% 
    dplyr::summarise(.groups="drop",date_Beg=min(date)) %>% 
    dplyr::mutate(year_week=format.Date(date_Beg,"%Y-%W"))%>% 
    dplyr::filter(year_week %in% weeks.in.data_runin$year_week)
  
  
  data_plot_Runin<-runin_dat |> 
    dplyr::left_join(data_Weeks_Runin,by=c("year","week"))
  
  data_plot_RuninB<-data_plot_Runin |> 
    dplyr::select(observed_rate,fitted,fittedp25,
                  fittedp975,outbreak,
                  threshold_rate,observed_alarm)  |>  
    dplyr::rename(observed=observed_rate,
                  threshold=threshold_rate)
  
  # data_use_Runin_xts<-xts(data_plot_RuninB,order.by =year_week_S_runin$date_Beg,
  #                         frequency=7)
  
  data_use_Runin_xts<-xts(data_plot_RuninB,order.by =data_plot_Runin$date,
                          frequency=7)
  
  data_plot_RuninB1<-data_plot_Runin |> 
    #dplyr::mutate(date=year_week_S_runin$date_Beg) |> 
    dplyr::select(date,observed_rate,fitted,fittedp25,
                  fittedp975,outbreak,
                  threshold_rate,observed_alarm)|> 
    dplyr::rename(observed=observed_rate,
                  threshold=threshold_rate)
  
  
  
  plot.runin<-ggplot(aes(x=date),data=data_plot_RuninB1)+
    geom_line(aes(x=date,y=observed,col="Observed"),linewidth=0.82)+
    geom_line(aes(x=date,y=fitted,col='Predicted'),linewidth=1.2,lty=1)+
    geom_line(aes(x=date,y=threshold),linewidth=1.1,lty=1,col='blue',show.legend =F)+
    geom_area(aes(x=date,y=threshold,fill='Endemic'),alpha=0.7)+
    geom_point(aes(x=date,y=observed_alarm,col="Outbreak"),size=3)+
    geom_ribbon(aes(ymin=fittedp25,ymax=fittedp975,
                    fill="95 % CI"),alpha=0.3)+
    scale_color_manual(values=c("Observed"='#00336FFF',
                                "Predicted"='#A72197FF',
                                #"Endemic"='lightblue2',
                                "Outbreak"='orange2'))+
    scale_fill_manual(values=c("Endemic"='lightblue2',
                               "95 % CI"=grey(0.3)))+
    
    scale_x_date(date_breaks ="52 weeks")+
    theme_bw()+
    guides(col=guide_legend(title =NULL),
           fill=guide_legend(title =NULL))+
    ylab("Incidence Rate\n per 100000")+
    theme_bw()
  
  #print(plot.runin)
  
  dat_Sensitivity<-all_cv |> 
    dplyr::select(district,year,week,Cases,mean_rate,sd_rate,week_Interval,Pop,mean,lci,uci) |> 
    dplyr::mutate(obs_rate=(Cases/Pop)*1e5,
                  p25=(lci/Pop)*1e5,
                  p975=(uci/Pop)*1e5,
                  predicted=(mean/Pop)*1e5,
                  Threshold=mean_rate+(sd_rate*Z_Value)
    ) |> 
    dplyr::filter(week_Interval=="04")
  
  Combined_sensitivy<-dat_Sensitivity |> 
    dplyr::left_join(y.PREDS,by=c("year","week","week_Interval")) |> 
    dplyr::rename(pred_Cases=value) |> 
    dplyr::mutate(pred_rate=(pred_Cases/Pop)*1e5,
                  outbreak=as.numeric(obs_rate>Threshold),
                  exceed=as.numeric(pred_rate>Threshold)) 
  
  
  
  probs_Exceed<-Combined_sensitivy |> 
    dplyr::group_by(district,year,week,week_Interval) |> 
    dplyr::summarise(.groups ="drop",
                     outbreak=mean(outbreak),
                     total=n(),
                     total_Exceed=sum(exceed),
                     exceed_prob=mean(exceed))
  
  
  
  data_use_<-dat_Sensitivity |> 
    dplyr::left_join(probs_Exceed,by=c("district","year","week"))|> 
    dplyr::mutate(observed1=(Cases/Pop)*1e5,
                  observed=case_when(is.na(observed1)~0,
                                     TRUE~observed1),
                  observed_alarm=case_when(outbreak==1~observed,
                                           TRUE~as.numeric(NA)))
  
  cat("computed probs \n")
  print(data_use_$exceed_prob)
  idx.comp<-which(!is.na(data_use_$outbreak))
  
  roc_try<-try(reportROC(gold=as.numeric(data_use_$outbreak)[idx.comp],
                         predictor=data_use_$exceed_prob[idx.comp]),outFile =warning("ROC_error.txt"))
  
  roc_tab_names<-c("Cutoff","AUC","AUC.SE","AUC.low","AUC.up","P","ACC",
                   "ACC.low","ACC.up","SEN","SEN.low","SEN.up",
                   "SPE","SPE.low","SPE.up","PLR","PLR.low",
                   "PLR.up","NLR","NLR.low","NLR.up","PPV",
                   "PPV.low","PPV.up","NPV","NPV.low","NPV.up")
  
  
  
  kdd<-data.frame(t(rep(as.character(NA),length(roc_tab_names))))
  names(kdd)<-roc_tab_names
  
  if(class(roc_try) %in% c("NULL","try-error")){
    roc_report<-kdd
  }else{
    roc_report<-reportROC(gold=as.numeric(data_use_$outbreak)[idx.comp],
                          predictor=data_use_$exceed_prob[idx.comp])
  }
  
  if(roc_report$Cutoff%in% c(NA,-Inf,NaN,Inf)){
    sens_ppv<-tribble(~var,~val,~CI_Lower,~CI_Upper,
                      "Cutoff probability",roc_report$Cutoff,NA,NA,
                      "Area under the Curve (AUC)",roc_report$AUC,roc_report$AUC.low,roc_report$AUC.up,
                      "Accuracy",roc_report$ACC ,roc_report$ACC.low,roc_report$ACC.up,
                      "Sensitivity",roc_report$SEN,roc_report$SEN.low,roc_report$SEN.up,
                      "Specificity",roc_report$SPE,roc_report$SPE.low,roc_report$SPE.up,
                      "Positive Predictive Value (PPV)",roc_report$PPV,roc_report$PPV.low,roc_report$PPV.up,
                      "Negative Predictive Value (NPV)",roc_report$NPV,roc_report$NPV.low,roc_report$NPV.up)
    
    data_use_a<-data_use_ %>% 
      dplyr::mutate(prob_exceed=exceed_prob,
                    cutoff=NA,
                    validation_alarm=as.numeric(NA))
    
  }else{
    sens_ppv<-tribble(~var,~val,~CI_Lower,~CI_Upper,
                      "Cutoff probability",roc_report$Cutoff,NA,NA,
                      "Area under the Curve (AUC)",roc_report$AUC,roc_report$AUC.low,roc_report$AUC.up,
                      "Accuracy",roc_report$ACC ,roc_report$ACC.low,roc_report$ACC.up,
                      "Sensitivity",roc_report$SEN,roc_report$SEN.low,roc_report$SEN.up,
                      "Specificity",roc_report$SPE,roc_report$SPE.low,roc_report$SPE.up,
                      "Positive Predictive Value (PPV)",roc_report$PPV,roc_report$PPV.low,roc_report$PPV.up,
                      "Negative Predictive Value (NPV)",roc_report$NPV,roc_report$NPV.low,roc_report$NPV.up)  
    
    data_use_a<-data_use_ %>% 
      dplyr::mutate(prob_exceed=exceed_prob,
                    cutoff=as.numeric(roc_report$Cutoff),
                    validation_alarm=case_when((prob_exceed>=cutoff)~prob_exceed,
                                               TRUE~as.numeric(NA)))
  }
  
  #data_test_ggplot<<-data_use_a
  ratio_scale<-max(data_use_a$p975,na.rm =T)/max(data_use_a$prob_exceed,na.rm =T)
  
  
  data_use_AA<-data_use_a %>% 
    dplyr::mutate(Trend=1:n(),
                  lab_week=paste0(year,'_',str_pad(week,width = 2,side="left",pad='0')),
                  ratio_scale_p=ratio_scale) %>% 
    dplyr::rename(threshold=Threshold)
  
  Num_YYears<-length(unique(data_use_AA$year))
  breaks_p<-seq(1,nrow(data_use_AA),4*Num_YYears)
  
  selected_zvalue_pros0<-shiny_obj1$selected_zvalue
  Selected_out_threshold0<-as.numeric(shiny_obj1$zvalue_sel_Ordered[1,"Cutoff"])
  
  selected_zvalue_pros<-ifelse(is.na(selected_zvalue_pros0),1.2,selected_zvalue_pros0)
  Selected_out_threshold<-ifelse(is.na(Selected_out_threshold0),0.1,Selected_out_threshold0)
  
  alarm_vars_pros<-shiny_obj1$alarm_vars
  
  Selected_lag_Vars_pros<-shiny_obj1$Selected_lag_Vars
  
  Computed_pred_Distance<-floor(mean(as.numeric(unlist(str_extract_all(Selected_lag_Vars_pros,"[:number:]+")))))
  
  meta_Prediction<-tribble(~var,~Value,
                           "Alarm indicators",paste0(alarm_vars_pros,collapse ='\n'),
                           "Selected lags",paste0(Selected_lag_Vars_pros,collapse ='\n'),
                           "Prediction distance",paste0(as.character(Computed_pred_Distance),' Weeks'),
                           "Z outbreak",as.character(selected_zvalue_pros),
                           "Alarm threshold",as.character(Selected_out_threshold),
                           
  )
  
  factor_vars<-c("Alarm indicators",
                 "Selected lags",
                 "Prediction distance",
                 "Z outbreak",
                 "Alarm threshold")
  
  meta_Prediction1<-meta_Prediction |> 
    dplyr::mutate(var=factor(var,levels=factor_vars),
                  id=1)
  
  meta_Prediction_wide<-meta_Prediction1 |> 
    dplyr::group_by(id) |> 
    tidyr::spread(var,'Value') |> 
    dplyr::ungroup() |> 
    dplyr::select(-id)
  
  
  list(District=district_D,
       "ROC_analysis"=sens_ppv,
       prediction_meta_Data=meta_Prediction
       #Runin_plot=print(plot.runin),
       #Descriptive_table=dat_kl_Long)
  )
  }else{
    list(warning=paste0("district ",district_D, " not in Surveillance data"))
  }
  
}



#*@post /Ewars_predict
#*@apiTitle generate prospective Predictions
#*@param  pros_csv_File:file
#* @param  config_File:file
#* @parser csv list(show_col_types=FALSE)
#* @parser all
##*@serializer csv


# pros_dat_name generate_DBII_report_html
function(req) 
{
  mp_f<-mime::parse_multipart(req)
  print(mp_f)
  pros_Pred_dat<-read.csv(mp_f$pros_csv_File$datapath)
  config_fl<-jsonify::from_json(mp_f$config_File$datapath)
  Pros_Dat_dir<-"./ewars_Files/prospective_data"
  if(!dir.exists(Pros_Dat_dir)) dir.create(Pros_Dat_dir,recursive =T)
  pros_dat_name<-"Prospective_data.csv"
  write.csv(pros_Pred_dat,file.path(Pros_Dat_dir,pros_dat_name),row.names =F)
 
  ## make all config variables available to the API
  configVars<-c("alarm_variables",
                "other_alarm_variables",
                "number_of_cases_var",
                "population_var",
                "nlag",
                "generate_DBI_report_html",
                "generate_DBII_report_html")
  
  for (ww in 1:length(configVars)){
    assign(configVars[ww],config_fl[[configVars[ww]]])
  }
  
  Output_dir<-"./ewars_Files/outputs"
  out_Path<-Output_dir
  shiny_obj_Main_pth<-file.path(out_Path,"For_Shiny")
  all_files_Path<-file.path(out_Path,"For_Shiny","All_district")
  shinyDBII_obj_Main_pth<-file.path(out_Path,"For_Shiny_DBII")
  shinyDBII_obj_pth<-file.path(out_Path,"For_Shiny_DBII")
  pred_weights_Main_pth<-file.path(out_Path,"Prediction_weights")
  
  
  get_Ojs<-function(){
    gc()
    readRDS(file.path(all_files_Path,"Shiny_Objs_all.rds"))
    
    
  }
  
  all_Objs<-get_Ojs()
  
  base_vars<-c("district","year","week")
  
  number_of_cases<-all_Objs[["number_of_cases"]]
  population_var<-all_Objs[["pop.var.dat"]]
  
  
  
  
  Prospective_Data<-get_D_ata(file.path(Pros_Dat_dir,pros_dat_name)) |> 
    dplyr::mutate(Cases=.data[[number_of_cases]],
                  Pop=.data[[population_var]],
                  log_Pop=log(.data[[population_var]]/1e5),
                  pop_offset=log_Pop,
                  observed_rate=(Cases/Pop)*1e5)
  
  
  all_districts_pros<-unique(Prospective_Data$district)
  
  
  cat(unique(Prospective_Data$district),sep='\n')
  
  #DD<-1
  
  ## districts in DBI run file
  #Districts_DBI_surve_Dat<-unique(all_Objs$all_endemic$district)
  # save the prospective data 
  saveRDS(Prospective_Data,file.path(all_files_Path,"Uploaded_Prospective_Data.rds"))
  
  Districts_DBI_surve_Dat<- readRDS(file.path(all_files_Path,"Districts_DBI_surve_Dat.rds"))
  
    
  source("DBII_predictions_Vectorized_API.R",local =T)
    
}

# extract certain values from the API after run

#* @get /retrieve_predicted_cases
##* @param retrieve_pred
#* @serializer json
##* @serializer contentType list(type="application/json")


function() # boundary file in .shp format
{
  
  # 
  # surv_path<-as.character(surv_path)
  # shape_fl<-as.character(shape_fl)
  
  surv_Dat_dir<-"./ewars_Files/surveillance_data"
  SHP_fl_dir<-"./ewars_Files/shape_files"
  Output_dir<-"./ewars_Files/outputs"
  
  shiny_obj_Main_pth<-file.path(Output_dir,"For_Shiny")
  shinyDBII_obj_Main_pth<-file.path(Output_dir,"For_Shiny_DBII")
  all_files_Path<-file.path(Output_dir,"For_Shiny","All_district")
  
  get_Ojs<-function(){
    gc()
    readRDS(file.path(all_files_Path,"Shiny_Objs_all.rds"))
    
    
  }
  
  all_Objs<-get_Ojs()
  

  Districts_DBI_surve_Dat<- readRDS(file.path(all_files_Path,"Districts_DBI_surve_Dat.rds"))
  
  
  base_vars<-c("district","year","week")
  
  number_of_cases<-all_Objs[["number_of_cases"]]
  population_var<-all_Objs[["pop.var.dat"]]
  
  
  # pros_dat_name<-as.character(pros_dat_name)
  # Pros_Dat_dir<-"./ewars_Files/prospective_data"
  
  Prospective_Data<-readRDS(file.path(all_files_Path,"Uploaded_Prospective_Data.rds"))
  
  
  all_districts_pros<-unique(Prospective_Data$district)
  
  
  cat(unique(Prospective_Data$district),sep='\n')
  
  
  
  all_districts_pros<-unique(Prospective_Data$district)
  
  
  cat(unique(Prospective_Data$district),sep='\n')
  
  ## retrieve predictions for all districts
  
  Dist_get<-all_districts_pros[all_districts_pros%in%Districts_DBI_surve_Dat]
  
  pros_for_json<-vector(mode="list",length =length(Dist_get))
  
  for (DD in 1:length(Dist_get)){
    
    District_Now<-Dist_get[DD]
    
   
      one_of_dist_str_pros<-paste0('(',DD,' of ',length(Dist_get),' districts)')
      
      Prospective_Data_Sub<-Prospective_Data |> 
        dplyr::filter(district==District_Now)
      
      dist_padded<-str_pad(District_Now,side="left",width=3,pad=0)
      shiny_obj_pth<-file.path(shiny_obj_Main_pth,paste0("District_",dist_padded))
      shinyDBII_obj_pth<-file.path(shinyDBII_obj_Main_pth,paste0("District_",dist_padded))
  
    
  
  
  get_Ojs1<-function(){
    gc()
    readRDS(file.path(shiny_obj_pth,"Shiny_Objs.rds"))
    
    
  }
  
  shiny_obj1<-get_Ojs1()
  
  reporT_pAth0<-shiny_obj1[["report_pth"]]
  
  reporT_pAth<-stringr::str_replace(reporT_pAth0,'.',getwd())
  
  system(paste0("echo ",reporT_pAth,"\n"))  
  
  #pros_pred_Obj0<-readRDS(file.path(reporT_pAth,"ewars_pros_Pred_Objects.rds"))[c("meta_Prediction","table_Out_pros")]
  
  #pros_pred_Obj<<-foreach(aa=c("meta_Prediction","table_Out_pros"),.combine =list)%do% readRDS(file.path(reporT_pAth,"ewars_pros_Pred_Objects.rds"))[[aa]]
  pros_pred_Obj0<-readRDS(file.path(reporT_pAth,"ewars_pros_Pred_Objects.rds"))[c("meta_Prediction","Plot_pros",
                                                                                  "all_Pros_Predictions_Week_Link",
                                                                                  "alarm_vars_pros","select_User_vars2")]
  
  
  Plot_pros00<-pros_pred_Obj0$Plot_pros
  all_Pros_Predictions_Week_Link00<-pros_pred_Obj0$all_Pros_Predictions_Week_Link
  alarm_vars_pros00<-pros_pred_Obj0$alarm_vars_pros
  select_User_vars00<-pros_pred_Obj0$select_User_vars2
  
  pros_pred_Obj0$meta_Prediction<-data.frame(district=pros_pred_Obj0$Plot_pros$district[1],
                                             pros_pred_Obj0$meta_Prediction)
  
  
  
  names(Plot_pros00)
  
  var_Keep_Pros0<-c("district",
                    "year.x",
                    "week.x",
                    "plot_lab",
                    "week_seq",
                    # "Cases",
                    # "population",
                    # "observed_rate",
                    #"outbreak_moving_limit",
                    "endemic_chanel",
                    #"outbreak_moving_sd",
                    "predicted_cases",
                    "predicted_cases_lci",
                    "predicted_cases_uci",
                    "predicted_rate",
                    "predicted_rate_lci",
                    "predicted_rate_uci",
                    #"endemic_threshold",
                    "alarm_threshold",
                    "outbreak_probability",
                    "alarm_signal",
                    "outbreak_period",
                    "pred_Distance",
                    "response_cat")
  
  var_Keep_Pros<-c(select_User_vars00,
                   #"outbreak_moving_limit",
                   "endemic_chanel",
                   #"outbreak_moving_sd",
                   "predicted_cases",
                   "predicted_cases_lci",
                   "predicted_cases_uci",
                   "predicted_rate",
                   "predicted_rate_lci",
                   "predicted_rate_uci",
                   #"endemic_threshold",
                   "alarm_threshold",
                   "outbreak_probability",
                   "alarm_signal",
                   "outbreak_period",
                   "pred_Distance",
                   "response_cat")
  
  names(all_Pros_Predictions_Week_Link00)
  
  Plot_pros_selected<-Plot_pros00 |> 
    dplyr::rename(response_cat0=response_cat) |> 
    dplyr::mutate(response_cat=case_when(response_cat0==0.5~"No response",
                                         response_cat0==1~"Initial response",
                                         response_cat0==1.5~"Early response",
                                         response_cat0==2~"Late/emergency response",
                                         TRUE~as.character(NA))) |> 
    dplyr::select(all_of(var_Keep_Pros0)) |> 
    dplyr::rename(year=year.x,
                  week=week.x,
                  plot_Week_lab=plot_lab) |> 
    dplyr::left_join(all_Pros_Predictions_Week_Link00,by=c("district","year","week")) |> 
    dplyr::select(all_of(var_Keep_Pros)) 
  
  pros_pred_Obj<-list(list(meta_Prediction=pros_pred_Obj0$meta_Prediction,
                      Prospective_prediction=Plot_pros_selected))
  names(pros_pred_Obj)<-District_Now
  
  pros_for_json[DD] <-pros_pred_Obj
  
  }
  
  pros_for_json
  #toJSON(pros_for_json)
  
}




